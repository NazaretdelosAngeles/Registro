<!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <link type="image/x-icon" href="main/img/icono2.png" rel="icon" />
  <title>Inicio</title>
  <link rel="stylesheet" href="main/css/bootstrap.min.css">  
  <style>
	.bgfondonav{
		//background-color:#F4F6F6;
		background-color:#FFFFFF;
		
	
	}
	body{
		background-color:#FFFFFF;
		//background-color:#F4F6F6;
		
	}

	a{
		text-decoration: none;
	}

	.carousel-inner img {
    width: 100%;
    height: 340px;
	}


	</style>
</head>
<body class="container-fluid">
<div class="bgfondonav  " id="bgfondonav">

	<nav aria-label="breadcrumb " class='justify-content-between ' id="bgfondonav">
  		<ol class="breadcrumb nav justify-content-end bgfondonav">
    		<li class="breadcrumb-item"><a href="login.php" class="text-dark">Iniciar Sessión</a></li>
  		</ol>
	</nav>

</div>

	

	<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
 		
  		<div class="carousel-inner" id="carousel-inner">
  			<div class="carousel-item active">
      			<img class="d-block w-100" src="main/img/icono1.png" alt="First slide">
    		</div>
    		<div class="carousel-item">
      			<img class="d-block w-100" src="main/img/a.jpeg" alt="First slide">
    		</div>
    		<div class="carousel-item">
      			<img class="d-block w-100" src="main/img/b.jpeg" alt="Second slide">
    		</div>
    		<div class="carousel-item">
      			<img class="d-block w-100" src="main/img/c.jpeg" alt="Third slide">
    		</div>
  		</div>
  			<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
   				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
    			<span class="sr-only">Anterior</span>
  			</a>
  			<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    			<span class="carousel-control-next-icon" aria-hidden="true"></span>
    			<span class="sr-only">Siguente</span>
  			</a>
	</div>

<br>

<div class="row justify-content-center">
  	<div class="col-6">
		<div class="card border-primary mb-3" >
  				<div class="card-body text-primary">
    				<h5 class="card-title">Registro Civil</h5>
    					<p class="card-text">
    						El Registro Civil es un servicio público esencial, su actividad será de carácter regular, continuo, ininterrumpido y orientado al servicio de las personas. Es obligatoria la inscripción de los actos y hechos declarativos, constitutivos o modificatorios del estado civil y la prestación del servicio es gratuita.
    					</p>
  				</div>
		</div>
	</div>

	<div class="col-6">
		<div class="card border-primary mb-3 " >
  				<div class="card-body text-primary">
    				<h5 class="card-title">Artículo 13 : LEY ORGÁNICA DE REGISTRO CIVIL</h5>
    					<p class="card-text">El Registro Civil utilizará tecnologías apropiadas para la realización de sus procesos, manteniendo la integridad de la información, garantizando la seguridad física, lógica y jurídica, así como la confiabilidad e inalterabilidad de sus datos, de conformidad con lo previsto en esta Ley, los reglamentos, resoluciones dictados por el Consejo Nacional Electoral y demás normativas vigentes.
    					</p>
  				</div>
		</div>
	</div>
</div>









<script src="main/js/jquery-3.6.0.min.js"></script>
<script src="main/js/bootstrap.min.js"></script>  
</body>
</html>
