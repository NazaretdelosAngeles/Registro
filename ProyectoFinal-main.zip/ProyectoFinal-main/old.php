<!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Inicio</title>
  <link rel="stylesheet" href="main/css/bootstrap.min.css">  
  <style>
	.bgfondo{
		background-color:#1ABC9C;
	}
	body{
		background-color:#45B39D ;
	}
	</style>
</head>
<body>
	<div class="bgfondo">
    	<nav class="navbar navbar-expand-md shadow-sm bg-light justify-content-between border-dark border-bottom">
  			<a class="navbar-brand text-dark  ">
  				<h2 class="text-justify">
  					Nombre del programa
  				<h2>
  			</a>
  				<h2 class=''>
  					<a class="btn btn-outline-success btn-lg font-weight-bold text-dark text-justify" href="login.php">
  						Iniciar sessión
  					</a>
  				</h2>
		</nav>
 	</div>

 	<br> 	<br> 	<br> 	<br> 	<br>

 	<div class="row justify-content-center ">
  		<div class="col-6 ">
    		<div class="card border border-dark rounded-3" >
      			<div class="card-body ">
        			<h5 class="card-title cover-heading text-center"><b>Nombre del programa </b></h5>
        				<p class="card-text">
        					Qué hace es programa :
        					With supporting text below as a natural lead-in to additional content , With supporting text below as a natural lead-in to additional content , With supporting text below as a natural lead-in to additional content , With supporting text below as a natural lead-in to additional content , With supporting text below as a natural lead-in to additional content
        				</p>
      			</div>
    		</div>
  		</div>
	</div>





<script src="main/js/jquery.js"></script>
<script src="main/js/popper.min.js"></script>
<script src="main/js/bootstrap.min.js"></script>  
</body>
</html>
