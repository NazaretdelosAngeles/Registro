<!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <link type="image/x-icon" href="main/img/icono2.png" rel="icon" />
  <title>Iniciar Sesión</title>
  <link rel="stylesheet" href="main/css/bootstrap.min.css">
  <style>
    body{
      background-color:#FFFFFF;
      //background-color:#F4F6F6;
    
    } 
  </style>
</head>
  <body class="container-fluid">
    <br><br><br>

  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card">
          <h3><div class="card-header">Iniciar Sesión</div></h3>
            <div class="card-body">
              <form method="POST" action="loginn.php">
                <div class="row mb-3">
                  <label for="uname" class="col-md-4 col-form-label text-md-end">Usuario: </label>
                  <div class="col-md-7">
                    <input id="uname" type="text" class="form-control" name="uname" value="" required autofocus placeholder="Aqui Usuario">
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="password" class="col-md-4 col-form-label text-md-end">Contraseña: </label>
                  <div class="col-md-7">
                      <input id="password" type="password" class="form-control" name="pword" required autocomplete placeholder="Aqui Contraseña">
                  </div>
                </div>
                        
                  <div class="row mb-3">
                      <div class="col-md-6 offset-md-4">
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" name="remember_me" id="remember_me">

                          <label class="form-check-label" for="remember">
                            Recuerdame clave
                          </label>
                        </div>
                      </div>
                    </div>
                        
                <div class="row mb-0">
                  <div class="col-md-8 offset-md-4">
                      <button type="submit" class="btn btn-primary">
                        Aceptar
                      </button>
                  </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>









<script src="main/js/jquery-3.6.0.min.js"></script>
<script src="main/js/bootstrap.min.js"></script>  
  </body>
</html>
