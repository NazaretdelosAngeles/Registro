
<form action="regciudadano.php" method="POST">
Nombres:<br>
<input type="text" name="nombres" required /><br><br>

Apellidos:<br>
<input type="text" name="apellidos"  required/><br><br>

Nacionalidad:<br>
<input type="text" name="nacionalidad" required /><br><br>

Cédula de Identidad:<br>
<input type="text" name="cedula" required/><br><br>

Fecha De Nacimiento:<br>
<input type="date" name="fecha_de_nacimiento" required/><br><br>
<input type="submit" value="Agregar Ciudadano" />
</form>