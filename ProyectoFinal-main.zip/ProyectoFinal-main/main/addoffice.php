<form action="saveoffice.php" method="post">
Nombre de Oficina <br>
<input type="text" name="officename"  required/>
<br>
<input type="submit" value="Guardar">
</form>