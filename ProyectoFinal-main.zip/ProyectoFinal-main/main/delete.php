<?php
	include('connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("DELETE FROM transaction WHERE id= :memid");
	$result->bindParam(':memid', $id);
	$result->execute();

	$idc=$_GET['id'];
	$resultc = $db->prepare("DELETE FROM ciudadano WHERE id= :memid");
	$resultc->bindParam(':memid', $idc);
	$resultc->execute();
?>