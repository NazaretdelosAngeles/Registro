<form action="savedoc.php" method="post">
Nombre<br>
<input type="text" name="docname" required />
<br>
<input type="submit" value="Guardar">
</form>