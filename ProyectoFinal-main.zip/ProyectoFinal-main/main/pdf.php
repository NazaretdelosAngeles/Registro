<?php
require('fpdf/fpdf.php');
require ("connect.php");

class PDF extends FPDF
{
// Cabecera de página 
    
function Header()
{
    // Logo
    $this->Image('img/logo.png',10,8,90);
    //$this->Image('img/x.jpg',10,8,60);
    //salto de linea
    $this->Ln(8);
    // Arial bold 15
    $this->SetFont('Times','',30);
    // Movernos a la derecha
    $this->Cell(80);
    // Salto de linea
    $this->Ln(30);
    // Tittulo
    $this->Cell(0,2,'Solicitud',0,0,'C');
    // Salto de línea
    $this->Ln(20);
}

//Pie de página
function Footer()
{
    // Posición: a 1,5 cm del final
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Número de página
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    // Posición: a 1,5 cm del final
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Número de página
    $this->Cell(5,10,utf8_decode('Página') .$this->PageNo().'/{nb}',0,0,'C');
}


}


   

// Creación del objeto de la clase heredada
$pdf = new PDF('P','mm','A4');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

#Establecemos los márgenes izquierda, arriba y derecha:
$pdf->SetMargins(30, 1 , 30);

#Establecemos el margen inferior:
$pdf->SetAutoPageBreak(true,1);


 //CONSULTA PARA DATOS DE LA TABLA TRANSACTION
    //$id='1';
    $id=$_GET['id'];
    $result = $db->prepare("SELECT * FROM transaction WHERE id= :userid");
    //$result=$db->prepare("SELECT * FROM transaction INNER JOIN ciudadano ON transaction.id = :userid ORDER BY ciudadano.id DESC ");
    $result->bindParam(':userid', $id);
    $result->execute();

// CONSULTA PARA DATOS DE LA TABLA CIUDADANO
   // $id=$_GET['id'];
    $resultc = $db->prepare("SELECT * FROM ciudadano WHERE id= :userid");
    //$result=$db->prepare("SELECT * FROM transaction INNER JOIN ciudadano ON transaction.id = :userid ORDER BY ciudadano.id DESC ");
    $resultc->bindParam(':userid', $id);
    $resultc->execute();




    for($i=0; $row = $result->fetch(); $i++){
        $pdf->MultiCell(1,1," ");

        $pdf->MultiCell(150,8,"Datos del Registro : ",'1','',0);
        $pdf->Ln(3);

        $pdf->MultiCell(100,8,utf8_decode("N° de Documento : "));
        $pdf->MultiCell(100,4,$row['id']);
        $pdf->Ln(3);

        $pdf->MultiCell(100,8,"Fecha de Solicitud : ");
        $pdf->MultiCell(100,4,$row['date']);
        $pdf->Ln(3);

        $pdf->MultiCell(100,8,"Fecha de Entraga : ");
        $pdf->MultiCell(100,4,$row['dateout']);
        $pdf->Ln(3);

        $pdf->MultiCell(100,8,"Emisor :");
        $pdf->MultiCell(100,4,utf8_decode($row['receive_by']));
        $pdf->Ln(3);

        $pdf->MultiCell(100,8,"Receptor :");
        $pdf->MultiCell(100,4,utf8_decode($row['ft']));
        $pdf->Ln(3);

        $pdf->MultiCell(100,8,"Tipo de Documento: ");
        $pdf->MultiCell(100,4,utf8_decode($row['doc_type']));
        $pdf->Ln(10);
    }



    for($i=0; $rowc = $resultc->fetch(); $i++){
        $pdf->MultiCell(1,1," ");
        $pdf->MultiCell(150,8,"Datos del Ciudadano : ",'1','',0);
        $pdf->Ln(3);

        $pdf->MultiCell(100,8,"Nombres : ");
        $pdf->MultiCell(100,4,utf8_decode($rowc['nombres']));
        $pdf->Ln(3);

        $pdf->MultiCell(100,8,"Apellidos :");
        $pdf->MultiCell(100,4,utf8_decode($rowc['apellidos']));
        $pdf->Ln(3);

        $pdf->MultiCell(100,8,utf8_decode("Cédula :"));
        $pdf->MultiCell(100,4,utf8_decode($rowc['cedula']));
        $pdf->Ln(3);

        $pdf->MultiCell(100,8,"Nacionalidad :");
        $pdf->MultiCell(100,4,utf8_decode($rowc['nacionalidad']));

    }
    


    $pdf->Output();
?>