<?php
// configuration
include('connect.php');
 
// new data
$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$nacionalidad = $_POST['nacionalidad'];
$cedula = $_POST['cedula'];
$fecha_de_nacimiento = $_POST['fecha_de_nacimiento'];
$id=$_POST['id'];

// query
$sql = "UPDATE ciudadano 
        SET nombres=?, apellidos=?, nacionalidad=?, cedula=?, fecha_de_nacimiento=?
		WHERE id=?";
$q = $db->prepare($sql);
$q->execute(array($nombres,$apellidos,$nacionalidad,$cedula,$fecha_de_nacimiento,$id));
header("location: ciudadano.php");

?>