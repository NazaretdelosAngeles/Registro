<?php
// configuration
include('connect.php');

// new data
$date = $_POST['date'];
$doc_type = $_POST['doc_type'];
$desc = $_POST['desc'];
$office = $_POST['office'];
$status = $_POST['status'];
$id = $_POST['memids'];
$dateo = $_POST['dateo'];
$rb = $_POST['rb'];
$ft = $_POST['ft'];
// query

$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$nacionalidad = $_POST['nacionalidad'];
$cedula = $_POST['cedula'];
$fecha_de_nacimiento = $_POST['fecha_de_nacimiento'];
$idc=$_POST['idc'];

// query
$sql = "UPDATE ciudadano 
        SET nombres=?, apellidos=?, nacionalidad=?, cedula=?, fecha_de_nacimiento=?
		WHERE id=?";
$q = $db->prepare($sql);
$q->execute(array($nombres,$apellidos,$nacionalidad,$cedula,$fecha_de_nacimiento,$idc));




$sqll = "UPDATE transaction 
        SET date=?, doc_type=?, description=?, office=?, status=?, dateout=?, receive_by=?, ft=?
		WHERE id=?";
$qq = $db->prepare($sqll);
$qq->execute(array($date,$doc_type,$desc,$office,$status,$dateo,$rb,$ft,$id));
header("location: index.php");

?>