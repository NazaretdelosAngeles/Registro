<?php
include('connect.php');	

$date = $_POST['date'];
$doc_type = $_POST['doc_type'];
$desc = $_POST['desc'];
$office = $_POST['office'];
$status = $_POST['status'];
$dateo = $_POST['dateo'];
$rb = $_POST['rb'];
$ft = $_POST['ft'];



$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$nacionalidad = $_POST['nacionalidad'];
$cedula = $_POST['cedula'];
$fecha_de_nacimiento = $_POST['fecha_de_nacimiento'];

// query para transaction


// query para agregar ciudadano
$s="INSERT INTO ciudadano(nombres,apellidos,nacionalidad,cedula,fecha_de_nacimiento) VALUES (:nombres,:apellidos,:nacionalidad,:cedula,:fecha_de_nacimiento)";
$p = $db->prepare($s);
$p->execute(array(':nombres'=>$nombres,':apellidos'=>$apellidos,':nacionalidad'=>$nacionalidad,':cedula'=>$cedula,':fecha_de_nacimiento'=>$fecha_de_nacimiento));



$sql = "INSERT INTO transaction (date,doc_type,description,office,status,dateout,receive_by,ft) VALUES (:sas,:asas,:asafs,:offff,:statttt,:dot,:rd,:ft)";
$q = $db->prepare($sql);
$q->execute(array(':sas'=>$date,':asas'=>$doc_type,':asafs'=>$desc,':offff'=>$office,':statttt'=>$status,':dot'=>$dateo,':rd'=>$rb,':ft'=>$ft));


header("location: index.php");





?>