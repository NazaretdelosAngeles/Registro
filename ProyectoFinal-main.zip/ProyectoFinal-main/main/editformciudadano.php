<?php
	include('connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("SELECT * FROM ciudadano WHERE id= :userid");
	$result->bindParam(':userid', $id);
	$result->execute();
	for($i=0; $rows = $result->fetch(); $i++){
?>
<form action="editciudadano.php" method="POST">
<input type="hidden" name="id" value="<?php echo $id; ?>" />

Nombres:<br>
<input type="text" name="nombres" value="<?php echo $rows['nombres']; ?>" /><br><br>

Apellidos:<br> 
<input type="text" name="apellidos" value="<?php echo $rows['apellidos']; ?>" /><br><br>

Nacionalidad:<br>
<input type="text" name="nacionalidad" value="<?php echo $rows['nacionalidad']; ?>" /><br><br>

Cédula de identidad:<br>
<input type="text" name="cedula" value="<?php echo $rows['cedula']; ?>" /><br><br>

Fecha de Nacimiento:<br>
<input type="date" name="fecha_de_nacimiento" value="<?php echo $rows['fecha_de_nacimiento']; ?>" /><br><br>

<input type="submit" value="Guardar o Modificar" />
</form>
<?php
	}
?>