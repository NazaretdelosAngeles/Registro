
<form action="reg.php" method="POST">
Fecha de Solicitud<br>
<input type="date" name="date" required /><br><br>
Fecha de Entrega<br>
<input type="date" name="dateo" required /><br><br>
Emisor<br>
<input type="text" name="rb" required /><br><br>
Tipo de Documento<br>
<select name="doc_type" class="ed" required>
	<?php 
	include('connect.php');		
		$result = $db->prepare("SELECT * FROM doc_type ORDER BY id DESC");
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
		echo '<option value="'.$row[name].'">'.$row[name].'</option>';
		}
	?>
</select><br /><br>
 Descripción <br>
<textarea name="desc" required></textarea><br><br>
Oficina<br>
<select name="office" class="ed" required>
	<?php
	include('connect.php');		
		$result = $db->prepare("SELECT * FROM offices ORDER BY id DESC");
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
		echo '<option value="'.$row[name].'">'.$row[name].'</option>';
		}
	?>
</select><br />
Estado<br>
<input type="text" name="status" required/><br><br>
Receptor<br>
<input type="text" name="ft" required/><br>
<hr>

Datos del Ciudadano:<br><br>
Nombres del Ciudadano:<br>
<input type="text" name="nombres" required /><br><br>

Apellidos del Ciudadano:<br>
<input type="text" name="apellidos"  required/><br><br>

Nacionalidad del Ciudadano:<br>
<input type="text" name="nacionalidad" required /><br><br>

Cédula de Identidad del Ciudadano:<br>
<input type="text" name="cedula" required/><br><br>

Fecha De Nacimiento del Ciudadano:<br>
<input type="date" name="fecha_de_nacimiento" required/><br><br>
<input type="submit" value="Guardar y Registrar" />
</form>